print('''
>>>>>      TUGAS 2    <<<<<<<
Menghitung Jumlah Bilangan Genap
----------------------------------\n''')
bilangangenap = []

for i in range(2,21,2):
    bilangangenap.append(i)
    
print(f'LIST BILANGAN GENAP : {bilangangenap}')
print(f'JUMLAH BILANGAN GENAP : ',len(bilangangenap))