print('''
>>>>>      SOAL 2    <<<<<<<
Menambahkan Data Ke List Dengan Input
----------------------------------\n''')
daftarhewan = []

print('SEBUTKAN 3 NAMA HEWAN!')
for i in range(3):
    add = input(f'HEWAN KE-{i+1} : ')
    daftarhewan.append(add)

daftarhewan = ','.join(daftarhewan)
print('\nDAFTAR 3 HEWAN : ',daftarhewan)
    
    