print('''
>>>>>      TUGAS 1    <<<<<<<
Menambahkan Data Ke List
----------------------------------\n''')

daftarbarang = []

for i in range(5):
    barang = input(f'MASUKAN BARANG KE {i+1} : ')
    daftarbarang.append(barang)


print(f'\nDAFTAR BARANG : {daftarbarang}')
