print('''
>>>>>      SOAL 3    <<<<<<<
Bilangan Ganjil
----------------------------------\n''')

for i in range(1,20,2):
    print(i)