print('''
>>>>>      SOAL 4    <<<<<<<
Menghitung Panjang Kata
----------------------------------\n''')

inputan = input('Masukan Kalimat : ')
jumlah = len(inputan)
print('TOTAL JUMLAH KATA DALAM KALIMAT : ',jumlah)