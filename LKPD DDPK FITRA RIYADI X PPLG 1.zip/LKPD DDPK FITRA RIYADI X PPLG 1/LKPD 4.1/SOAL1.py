print('''
>>>>>      SOAL 1    <<<<<<<
For Loop Dengan Rentang Angka
----------------------------------\n''')

for i in range(1,11):
    print(i)