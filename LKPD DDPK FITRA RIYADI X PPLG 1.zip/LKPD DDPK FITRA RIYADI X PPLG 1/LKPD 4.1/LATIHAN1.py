print('''
>>>>>      LATIHAN 1    <<<<<<<
Menjumlahkan Bilangan
----------------------------------\n''')

angkalist = []

for i in range(5):
    bilangan = int(input(f'MASUKAN ANGKA KE-{i+1} : '))
    angkalist.append(bilangan)
    
has = 0
for jum in angkalist:
    has += jum
    
print('\nJumlah Total Angka : ',has)
    
