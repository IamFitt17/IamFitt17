print('''
>>>>>      LATIHAN 2    <<<<<<<
Menampilkan Huruf Vokal Dalam Kalimat
----------------------------------\n''')

kalimat = input('Masukan Kalimat : ').lower()

vokals = ['a','i','u','e','o']

voks = []
for teks in kalimat:
    if teks in vokals:
        voks.append(teks)
        

voks = ','.join(voks)        
print('Huruf Vokal Dalam Kalimat : ',voks)
        