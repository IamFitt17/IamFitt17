print('''
>>>>>      SOAL 1    <<<<<<<
----------------------------------\n''')
start = 1
bil1 = 0
bil2 = 1
while start <= 5:
    print(bil1)
    print(bil2)
    
    bil1 = bil1 + bil2
    bil2 = bil1 + bil2
    
    start += 1