print('''
>>>>>      SOAL 3    <<<<<<<
----------------------------------\n''')
def prima(x):
    return True

def prima(x):
    for c in range(2,x):
        if x % c == 0:
            return False
    
        return True


def bilanganprima(awal,akhir):
    listprima = []
    for i in range(awal,akhir + 1):
        if prima(i):
            listprima.append(i)
    return listprima


print(bilanganprima(1,50))
            
            