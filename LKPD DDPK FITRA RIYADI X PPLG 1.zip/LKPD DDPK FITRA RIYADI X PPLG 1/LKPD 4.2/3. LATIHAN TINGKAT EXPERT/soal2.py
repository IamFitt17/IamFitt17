print('''
>>>>>      SOAL 2    <<<<<<<
----------------------------------\n''')
bil = int(input('Masukan Faktorial : '))
asli = bil

tamb = 1

if bil < 0:
    print('Tidak Bisa Menghitung Factorial Dengan Angka Negatif!')
elif bil == 0:
    print('Faktorial Dari 0 Adalah 1!')
else:
    while bil > 0:
        tamb = tamb * bil
        bil = bil - 1
    print(f'Factorial Dari {asli} Adalah {tamb}!')
    