import random
print('''
>>>>>      SOAL 1    <<<<<<<
----------------------------------\n''')
jawaban = random.randint(1,10)

print('TEBAK ANGKA!!\n')
while True:
    tebak = int(input('\nPILIH ANGKA 1-10 : '))
    if tebak == jawaban:
        print(f'TEBAKAN ANDA BENAR! ADALAH ANGKA {jawaban}!')
        break
    else :
        print('TEBAKAN ANDA SALAH!')
    
print('\nPROGRAM BERHENTI.')