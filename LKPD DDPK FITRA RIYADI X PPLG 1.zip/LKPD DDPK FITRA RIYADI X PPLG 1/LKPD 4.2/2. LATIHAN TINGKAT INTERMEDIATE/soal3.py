import time
print('''
>>>>>      SOAL 3    <<<<<<<
----------------------------------\n''')

menu = True
login = False
register = False
ket = 'BELUM TERDAFTAR'
idcek = False
passcek = False
id = False
password = False

isRun = True
while isRun:
    if menu == True:
        select = int(input(f'''
----------- LOG IN --------------
PROPILE : {ket}
1. LOGIN AKUN
2. REGISTER AKUN
3. EXIT
----------------------------------
PILIH 1/2/3 : '''))
        if select == 1:
            menu = False
            login = True
        elif select == 2 :
            menu = False
            register = True
        else :
            print('\033c')
            print('PROGRAM DIHENTIKAN!')
            break
    
    if login == True:
        print('LOGIN ACOUNT\n---------------')
        idcek = input('MASUKAN ID : ')
        passcek = input('MASUKAN PASSWORD : ')
        if idcek == id:
            cek1 = True
        else:
            cek1 = False
        
        if passcek == password:
            cek2 = True
        else :
            cek2 = False
        
        if cek1 == True and cek2 == True:
            print(f'AKUN BERHASIL DIDAFTARKAN!')
            ket = 'TERDAFTAR!'
        else:
            print('ID ATAU PASSWORD YANG DIMASUKAN SALAH!')
        
        
        time.sleep(2.5)
        print('\033c')
        login = False
        menu = True
    
    if register == True:
        print('REGISTRASI ACCOUNT\n---------------')
        id = input('MASUKAN ID : ')
        password = input('MASUKAN PASSWORD : ')
        print('\nAKUN BERHASIL DIREGISTRASI!')
        time.sleep(2.5)
        print('\033c')
        register = False
        menu = True
        
        
        