print('''
>>>>>      SOAL 2    <<<<<<<
----------------------------------\n''')

start = 1
while start <= 100:
    print(start)
    start += 1