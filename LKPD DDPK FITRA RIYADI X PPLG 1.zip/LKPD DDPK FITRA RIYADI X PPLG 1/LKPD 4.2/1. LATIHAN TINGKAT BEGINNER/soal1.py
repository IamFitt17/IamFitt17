print('''
>>>>>      SOAL 1    <<<<<<<
----------------------------------\n''')
start = 1
while start <= 5:
    print(start)
    start += 1