print('''
>>>>>      SOAL 3    <<<<<<<
----------------------------------\n''')
start = 2
while start <= 10:
    print(start)
    start += 2