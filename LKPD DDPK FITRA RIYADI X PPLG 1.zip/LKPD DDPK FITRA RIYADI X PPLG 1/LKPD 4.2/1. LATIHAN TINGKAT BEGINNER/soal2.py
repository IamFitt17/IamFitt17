print('''
>>>>>      SOAL 2    <<<<<<<
----------------------------------\n''')
while True:
    angka = int(input('Masukan Angka Postif : '))
    if angka <= -1:
        print('Anda Memasukan Angka Negatif!\nProgram Berhenti.')
        break
